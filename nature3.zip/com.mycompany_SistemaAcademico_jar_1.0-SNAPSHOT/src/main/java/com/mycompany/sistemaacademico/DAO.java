package com.mycompany.sistemaacademico;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DAO {
    public boolean existe(Usuario usuario)
            throws Exception{ 
        String sql = "SELECT * FROM " +
            "tb_usuario WHERE " +
            "login = ? AND senha = ?";
        try(Connection conn = 
                ConexaoBD.obtemConexao();
            PreparedStatement ps =
                conn.prepareStatement(sql)
        ){
            ps.setString(1,usuario.getLogin());
            ps.setString(2,usuario.getSenha());
            try(ResultSet rs = ps.executeQuery()){
                return rs.next();   
            }
        }   
    }
    
    public void inserir(Medicamentos medicamentos) throws Exception{
       String sql = "INSERT INTO tb_medicamentos (nome, sintomas) VALUES (?, ?)";

    System.out.println("Iniciando a inserção do medicamento...");

    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        System.out.println("Conexão com o banco de dados obtida.");

        // Verificação nula para 'nome'
        if (medicamentos.getNome() == null) {
            System.err.println("Erro: O campo 'nome' não pode ser nulo.");
            return;
        }

        // Verificação nula para 'sintomas'
        if (medicamentos.getSintomas() == null) {
            System.err.println("Erro: O campo 'sintomas' não pode ser nulo.");
            return;
        }

        // Definindo os valores dos parâmetros
        ps.setString(1, medicamentos.getNome());
        ps.setString(2, medicamentos.getSintomas());

        System.out.println("Valores definidos: " + medicamentos.getNome() + ", " + medicamentos.getSintomas());

        // Executando o comando SQL
        int rowsAffected = ps.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Medicamento inserido com sucesso!");
        } else {
            System.out.println("Falha ao inserir o medicamento.");
        }
    } catch (SQLException e) {
        // Capturando e imprimindo qualquer exceção SQL
        System.err.println("Erro SQL: " + e.getMessage());
        e.printStackTrace();
    } catch (Exception e) {
        // Capturando e imprimindo qualquer outra exceção
        System.err.println("Erro: " + e.getMessage());
        e.printStackTrace();
    }
    } 
    
    public void atualizar(Medicamentos medicamentos) throws Exception{
        String sql = "UPDATE tb_medicamentos SET nome = ?, sintomas = ? WHERE id = ?";

    try (Connection conn = ConexaoBD.obtemConexao();
         PreparedStatement ps = conn.prepareStatement(sql)) {

        // Definindo os valores dos parâmetros
        ps.setString(1, medicamentos.getNome());
        ps.setString(2, medicamentos.getSintomas());
        ps.setInt(3, medicamentos.getId());

        // Executando o comando SQL
        int rowsAffected = ps.executeUpdate();

        if (rowsAffected > 0) {
            System.out.println("Medicamento atualizado com sucesso!");
        } else {
            System.out.println("Falha ao atualizar o medicamento.");
        }
    } catch (SQLException e) {
        // Capturando e imprimindo qualquer exceção SQL
        System.err.println("Erro SQL: " + e.getMessage());
        e.printStackTrace();
    } catch (Exception e) {
        // Capturando e imprimindo qualquer outra exceção
        System.err.println("Erro: " + e.getMessage());
        e.printStackTrace();
    }
    }
    
public void excluir(Medicamentos medicamentos) throws Exception{
    
    String sql = "DELETE FROM tb_medicamentos WHERE id = ?";
    
    try(Connection conn = ConexaoBD.obtemConexao();
            PreparedStatement ps = conn.prepareStatement(sql)){
        
        ps.setInt(1, medicamentos.getId());
        ps.execute();
    }
}
}
